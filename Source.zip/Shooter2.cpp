// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "Shooter2.h"
#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY(Shooter2);
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, Shooter2, "Shooter2");
 