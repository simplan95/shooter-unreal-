// For command line git tutorial
// First: GitHub modification
// Second: Local repository modification

print("Hello world")
print("Tell Your World")
print("Tell his world")
print("Tell her world")
print("Tell my world")
